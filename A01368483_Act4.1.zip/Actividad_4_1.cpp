//Andrea Galindo Yáñez
//A01368483
//Actividad 4.1 

//LIBRERÍAS 
#include <iostream>
using namespace std;

//CÓDIGO
struct Nodo {
	int x, y;
};

//FUNCIÓN PARA DETERMINAR LA ORIENTACIÓN 
int Orientacion_Nodo (Nodo p, Nodo q, Nodo r) {
	int valor = (q.y - p.y) * (r.x - q.x) - (q.x - p.x) * (r.y - q.y);
	if (valor == 0) return 0;
	return (valor > 0) ? 1 : 2;
}

//FUNCIÓN LOS NODOS 
bool Segmento_Nodo (Nodo p, Nodo q, Nodo r) {
	if (q.x <= max (p.x, r.x) && q.x >= min (p.x, r.x) &&
	q.y <= max (p.y, r.y) && q.y >= min (p.y, r.y)) 
		return true;
	return false;		
}

//FUNCIÓN PARA VERIFICAR LOS NODOS 
bool Interseccion_Nodo (Nodo p1, Nodo q1, Nodo p2, Nodo q2) {
	int o1 = Orientacion_Nodo(p1, q1, p2);
	int o2 = Orientacion_Nodo(p1, q1, q2);
	int o3 = Orientacion_Nodo(p2, q2, p1);
	int o4 = Orientacion_Nodo(p2, q2, q1);
	
	if (o1 != o2 && o3 != o4) 
		return true;
	
	if (o1 == 0 && Segmento_Nodo(p1, p2, q1)) return true;
	if (o2 == 0 && Segmento_Nodo(p1, q2, q1)) return true;
	if (o3 == 0 && Segmento_Nodo(p2, p1, q2)) return true;
	if (o4 == 0 && Segmento_Nodo(p2, q1, q2)) return true;
	
	return false;
}

int main () {
	int n;
	cout << "Ingrese el valor de n : ";
	cin >> n; 
	for (int i = 0; i < n; i++) {
		Nodo p1, p2, q1, q2;
		cin >> p1.x >> p1.y >> p2.x >> p2.y >> q1.x >> q1.y >> q2.x >> q2.y;
		if (Interseccion_Nodo(p1,p2,q1,q2)) {
			cout << "True" << endl;
		} else {
			cout << "False" << endl;
		}
	}
	
	return 0; 
}

//REFERENCIAS 
//Foro de Elhacker.NET. (s. f.). Foro elhacker.NET. https://foro.elhacker.net/programacion_cc/calcular_la_interseccion_de_dos_segmentos-t343325.0.html